data:extend(
{
  {
    type = "mining-tool",
    name = "dummy-steel-axe",
    icon = "__base__/graphics/icons/steel-axe.png",
    icon_size = 32,
    durability = 1,
    subgroup = "tool",
    order = "a[mining]-b[steel-axe]",
    flags = {"hidden"},
    stack_size = 1
  }
}
)
