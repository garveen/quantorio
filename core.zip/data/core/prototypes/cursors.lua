data:extend({

  {
    type = "mouse-cursor",
    name = "selection-tool-cursor",
    filename = "__core__/graphics/cross-select-x32.png",
    hot_pixel_x = 16,
    hot_pixel_y = 16
  },
  --{
  --  type = "mouse-cursor",
  --  name = "system-crosshair",
  --  system_cursor = "crosshair", -- one of "arrow", "i-beam", "crosshair", "wait-arrow", "size-all", "no", "hand"
  --}
  
})
