data:extend(
{
  {
    type = "god-controller",
    name = "default",

    crafting_categories = {"crafting"},
    mining_categories = {"basic-solid"},
    inventory_size = 60,
    item_pickup_distance = 1,
    loot_pickup_distance = 2,
    movement_speed = 0.5,
    mining_speed = 0.1
  }
})
